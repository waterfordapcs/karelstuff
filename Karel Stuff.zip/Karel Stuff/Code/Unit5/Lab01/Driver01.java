	//Name______________________________ Date_____________
  

   import java.io.*;
    public class Driver01
   {
       public static void main(String[] args)
      {
      	//input
         double[] myArray = {2.0, 3.7, 9.9, 8.1, 8.5, 7.4, 1.0, 6.2};
      				      
      	//sort the array
         int maxIndex;
         double temp;
      	/*********************************
      	*   write your code here
      	*
      	*********************************/
      			  
      	//output
         
         
      	
      }
   }