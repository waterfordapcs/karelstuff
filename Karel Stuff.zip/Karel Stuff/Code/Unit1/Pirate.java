	//Torbert, e-mail: mr@torbert.com, website: www.mr.torbert.com
	//version 4.16.2003

   import edu.fcps.karel2.Display;
    public class Pirate extends Athlete
   {
       public Pirate()
      {
        
      }
       public void approachPile()
      {
        
      }
       public int numOfBeepersInPile()
      {
        
      }
       public void turnAppropriately(int beepers)
      {
      
      }
   }