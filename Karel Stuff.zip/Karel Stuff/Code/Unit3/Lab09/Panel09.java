  //Name______________________________ Date_____________
   import javax.swing.*;
   import java.awt.*;
   import java.awt.event.*;
    public class Panel09 extends JPanel
   {
      private JLabel label;
      private double total;
       public Panel09()
      {
         setLayout(new BorderLayout());
         total = 0.0;
      
           	/***********************************/
         	/* Create and add the subpanel     */
         	/*                                 */
      		/*                                 */
         	/* Add the big label               */
         	/*                                 */
         	/***********************************/
      }
       private void addButton(JPanel panel, String s, double x)
      {
           	/************************/
         	/*                      */
         	/* Your code goes here. */
         	/*                      */
         	/************************/
           
      }
       private class Listener implements ActionListener
      {
         private double myX;
          public Listener(double x)
         {
            myX = x;
         }
          public void actionPerformed(ActionEvent e)
         {
           	/************************/
         	/*                      */
         	/* Your code goes here. */
         	/*                      */
         	/************************/ 
         }
      }
   }