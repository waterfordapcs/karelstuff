	//Name______________________________ Date_____________
   import javax.swing.*;
   import java.awt.*;
   import java.awt.event.*;
   public class Panel05 extends JPanel
   {
      private Display05 display;
      public Panel05()
      {
         setLayout(new FlowLayout());
      
         display = new Display05();
         add(display);
      
         JButton button = new JButton("Press Your Luck");
         button.addActionListener(new Listener());
         add(button);
      }
      private class Listener implements ActionListener
      {
         public void actionPerformed(ActionEvent e)
         {
         
         	/************************/
         	/*                      */
         	/* Your code goes here. */
         	/*                      */
         	/************************/
         
         }
      }
   }